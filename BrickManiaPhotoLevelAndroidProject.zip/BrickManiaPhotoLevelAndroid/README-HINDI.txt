BRICK MANIA PHOTO LEVELS - ANDROID PROJECT

This is a playable brick-breaker prototype with photo-to-brick custom levels.
It is a project source package, not a compiled APK.

To build APK on a computer:
1. Open/import this project in Android Studio, or push files to a new GitHub repository.
2. Use the included GitHub Actions workflow (.github/workflows/build-apk.yml).
3. In GitHub: Actions > Build Android APK > Run workflow.
4. Download the GamingPhotoMaker-debug-apk artifact after the build succeeds.
5. Extract the artifact ZIP to get app-debug.apk and install it on your Android phone.

Features: paddle controls, bouncing ball, brick collisions, score, lives, levels, gallery photo upload, photo colours converted into a brick pattern, Neon/Fire/Ice styles.

This is an original basic prototype inspired by the brick-breaker genre, not a copy of Brick Mania's proprietary artwork or code.
